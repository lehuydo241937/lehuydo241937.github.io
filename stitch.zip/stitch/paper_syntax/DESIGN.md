# Design System Strategy: The Digital Editorial

## 1. Overview & Creative North Star
The Creative North Star for this design system is **"The Quiet Authority."** 

Moving beyond basic minimalism, this system treats the personal blog as a high-end digital gallery. It rejects the "template" look of standard CMS platforms by prioritizing extreme white space, intentional asymmetry, and a focus on high-contrast typographic scales. The goal is to create an atmosphere of technical precision and intellectual depth, where the content isn't just displayed—it is curated. We achieve this by replacing rigid structural lines with "tonal zones" and sophisticated layering, ensuring the interface feels like an organic extension of the writing.

---

## 2. Colors: Tonal Atmosphere
Our palette is a study in monochromatic nuance, using a spectrum of greys to define space without the "noise" of traditional borders.

### The Palette
- **The Core:** `background` (#f8f9fa) and `surface` provide a crisp, paper-like foundation.
- **The Accent:** `primary` (#485f84) is our single point of focused energy. Use it sparingly for key actions and links to maintain its impact.
- **The Depth:** `surface-container` tiers (Lowest to Highest) are the primary tools for building hierarchy.

### Signature Rules
*   **The "No-Line" Rule:** Explicitly prohibit 1px solid borders for sectioning. Boundaries must be defined solely through background color shifts. A `surface-container-low` (#f1f4f6) section should sit flush against a `surface` background to denote a change in context.
*   **Surface Hierarchy & Nesting:** Treat the UI as stacked sheets of fine paper. A card should not have a border; it should be a `surface-container-lowest` (#ffffff) element resting on a `surface-container` (#eaeff1) background. This "nested depth" creates a premium, tactile feel.
*   **The "Glass & Gradient" Rule:** To elevate hero sections, use subtle linear gradients transitioning from `primary` (#485f84) to `primary-container` (#d5e3ff) at a 15% opacity. For floating navigation or overlays, apply **Glassmorphism**: use `surface` with 80% opacity and a `backdrop-filter: blur(12px)`.

---

## 3. Typography: The Editorial Voice
Typography is the architectural backbone of this system. We pair the technical precision of **Inter** with the structural elegance of **Manrope**.

*   **Display & Headlines (Manrope):** Large, bold, and authoritative. Use `display-lg` (3.5rem) for article titles with a `-0.02em` letter-spacing to create a "tight," professional editorial look.
*   **Body (Inter):** Optimized for long-form readability. `body-lg` (1rem) is the standard for article content, utilizing a generous line-height (1.6) to ensure the eye never tires.
*   **Labels & Metadata (Inter):** Use `label-md` (0.75rem) in `secondary` (#5e5f60) for dates and categories. These should be set in uppercase with `0.05em` letter-spacing to provide a technical, "data-stamped" aesthetic.

---

## 4. Elevation & Depth: Tonal Layering
We do not use shadows to simulate height; we use light and transparency.

*   **The Layering Principle:** Depth is achieved by "stacking" surface tiers. Place a `surface-container-lowest` card on a `surface-container-low` section to create a soft, natural lift.
*   **Ambient Shadows:** If a floating element (like a modal or dropdown) requires a shadow, it must be "Ambient": `box-shadow: 0 20px 40px rgba(43, 52, 55, 0.06)`. The shadow color is a tinted version of `on-surface`, never a neutral black.
*   **The "Ghost Border" Fallback:** When contrast is strictly required for accessibility (e.g., input fields), use a "Ghost Border." Apply the `outline-variant` (#abb3b7) at **15% opacity**. 100% opaque borders are strictly forbidden.

---

## 5. Components: Minimalist Primitives

### Buttons
*   **Primary:** Solid `primary` (#485f84) with `on-primary` text. Use `roundedness-md` (0.375rem).
*   **Secondary:** `surface-container-high` background with `on-surface` text. No border.
*   **Tertiary:** Ghost style. `on-surface` text with a subtle `primary` underline (2px) that expands on hover.

### Input Fields
*   **Style:** Background set to `surface-container-low`, Ghost Border (15% opacity `outline-variant`).
*   **States:** On focus, the border opacity increases to 100% using the `primary` color, accompanied by a subtle 2px soft glow.

### Cards & Lists
*   **Editorial Cards:** Forbid divider lines. Separate content using the Spacing Scale (e.g., `spacing-8` between article abstracts).
*   **Hover State:** Cards should not lift or grow. Instead, change the background from `surface` to `surface-container-lowest` and subtly shift the text color of the title to `primary`.

### Progress Indicators (Reading Bar)
*   A 2px fixed bar at the top of the viewport using the `primary` (#485f84) token, tracking scroll depth. This provides a "technical" utility feel without cluttering the UI.

---

## 6. Do's and Don'ts

### Do
*   **Do** use asymmetrical margins. Offsetting the main content column to the right creates a sophisticated, "magazine" layout.
*   **Do** use the `spacing-20` (7rem) token for section padding to allow the design to "breathe."
*   **Do** use `primary-fixed-dim` for subtle background highlights behind important pull-quotes.

### Don't
*   **Don't** use pure black (#000000) for text. Always use `on-surface` (#2b3437) to maintain visual softness.
*   **Don't** use standard "Drop Shadows" with high opacity. They break the "Quiet Authority" aesthetic.
*   **Don't** use dividers or hair-line rules to separate list items. Use whitespace (`spacing-4`) or tonal shifts instead.